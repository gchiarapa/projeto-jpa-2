package br.com.alura.jpa.modelo;

public enum TipoMovimentacao {
	ENTRADA, SAIDA;
}
